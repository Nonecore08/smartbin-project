# SmartBin Application

This package contains everything you need to run, build, and deploy the **SmartBin Waste Sorting Application**.

## Contents
- `index.html` → Landing page with download links
- `docs/` → Setup, deployment, and project information
- `archives/` → Application archives (source code + production build)
- `assets/` → Logos/images

## Quick Start
1. Extract the source archive:
   ```bash
   tar -xzf archives/smartbin-app.tar.gz -C ~/projects/smartbin
   cd ~/projects/smartbin
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run development server:
   ```bash
   npm run dev
   ```
4. Build production version:
   ```bash
   npm run build
   ```

For deployment instructions, check [docs/deployment.md](docs/deployment.md).
