# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

# Commands

```bash
npm run dev
npm run build
npm run typecheck
```
