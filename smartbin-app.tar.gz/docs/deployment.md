# Deployment Instructions

- **Vercel**: Auto-detects Vite projects
- **Netlify**: Build = `npm run build`, Publish dir = `dist`
- **GitHub Pages**: Use `gh-pages` package to deploy `dist`
