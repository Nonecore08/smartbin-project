# SmartBin Backend (Express + SQLite)

This is a lightweight backend for the SmartBin app. It provides:
- User registration / login (JWT)
- Simple endpoints for bins, user progress, and leaderboard
- SQLite database stored locally

## Quick start

1. Install dependencies:
```bash
npm install
```

2. Run migrations (creates local SQLite DB and tables):
```bash
npm run migrate
```

3. Start server:
```bash
npm start
# or for development with auto-reload:
npm run dev
```

Server runs on `http://localhost:4000` by default.

## API (examples)

- POST /api/auth/register  { name, email, password }
- POST /api/auth/login     { email, password }
- GET  /api/bins           list bins
- POST /api/progress       record user progress (protected)
- GET  /api/leaderboard    get leaderboard