
const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const dbPath = path.join(__dirname, '..', 'data', 'smartbin.sqlite');
const secret = process.env.JWT_SECRET || 'change_this_secret';

// register
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
  const db = new sqlite3.Database(dbPath);
  const hashed = await bcrypt.hash(password, 10);
  db.run('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, hashed], function(err) {
    if (err) return res.status(400).json({ error: 'Email may be already registered' });
    const user = { id: this.lastID, name, email };
    const token = jwt.sign(user, secret, { expiresIn: '7d' });
    res.json({ user, token });
  });
  db.close();
});

// login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const db = new sqlite3.Database(dbPath);
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (!row) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, row.password);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const user = { id: row.id, name: row.name, email: row.email };
    const token = jwt.sign(user, secret, { expiresIn: '7d' });
    res.json({ user, token });
  });
  db.close();
});

module.exports = router;
