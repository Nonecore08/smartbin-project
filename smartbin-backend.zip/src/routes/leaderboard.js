
const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, '..', 'data', 'smartbin.sqlite');

// GET /api/leaderboard
// returns top users by max score or sum score
router.get('/', (req, res) => {
  const db = new sqlite3.Database(dbPath);
  const sql = `
    SELECT u.id, u.name, u.email, MAX(p.score) as best_score, SUM(p.score) as total_score
    FROM users u
    LEFT JOIN progress p ON p.user_id = u.id
    GROUP BY u.id
    ORDER BY best_score DESC
    LIMIT 20
  `;
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(rows);
  });
  db.close();
});

module.exports = router;
