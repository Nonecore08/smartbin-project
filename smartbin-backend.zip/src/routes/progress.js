
const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const auth = require('../middleware/auth');
const dbPath = path.join(__dirname, '..', 'data', 'smartbin.sqlite');

// POST /api/progress  (protected)
router.post('/', auth, (req, res) => {
  const { score, level } = req.body;
  const userId = req.user.id;
  const db = new sqlite3.Database(dbPath);
  db.run('INSERT INTO progress (user_id, score, level) VALUES (?, ?, ?)', [userId, score, level], function(err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ id: this.lastID, user_id: userId, score, level });
  });
  db.close();
});

// GET /api/progress/:userId
router.get('/:userId', (req, res) => {
  const db = new sqlite3.Database(dbPath);
  db.all('SELECT * FROM progress WHERE user_id = ?', [req.params.userId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(rows);
  });
  db.close();
});

module.exports = router;
