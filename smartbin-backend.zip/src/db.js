
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, '..', 'data', 'smartbin.sqlite');

const fs = require('fs');
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)){
  fs.mkdirSync(dir, { recursive: true });
}

const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  // users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // progress table
  db.run(`CREATE TABLE IF NOT EXISTS progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    score INTEGER,
    level TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  // bins table (sample data)
  db.run(`CREATE TABLE IF NOT EXISTS bins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    type TEXT,
    description TEXT
  )`);

  // leaderboard is derived from progress; no table needed
});

// insert sample bins if empty
db.get("SELECT COUNT(*) as cnt FROM bins", (err, row) => {
  if (err) return console.error(err);
  if (row.cnt === 0) {
    const stmt = db.prepare("INSERT INTO bins (name, type, description) VALUES (?, ?, ?)");
    const sample = [
      ['Paper Bin', 'recyclable', 'For paper waste'],
      ['Organic Bin', 'organic', 'For food and organic waste'],
      ['Plastic Bin', 'recyclable', 'For plastic waste'],
      ['Hazardous Bin', 'hazardous', 'For hazardous items']
    ];
    sample.forEach(s => stmt.run(s));
    stmt.finalize();
    console.log('Inserted sample bins');
  }
});

db.close();
console.log('Migration complete. DB created at ' + dbPath);
