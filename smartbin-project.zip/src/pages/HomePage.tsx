function HomePage() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-black">
      <div className="flex items-center gap-4">
        <h1 className="text-[40px] font-medium tracking-[-0.02em] text-white/95" style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "Helvetica Neue", Arial, sans-serif' }}>
          Magic in Progress…
        </h1>
      </div>
    </div>
  );
}

export default HomePage;