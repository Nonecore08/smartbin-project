# Project Structure

```
src/
  App.tsx
  pages/
  utils/
dist/
package.json
vite.config.ts
tailwind.config.js
```
