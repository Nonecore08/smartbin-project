# Features

- Interactive waste sorting demo
- Gamified learning
- Progress tracking
- PWA offline support
- Responsive mobile design
