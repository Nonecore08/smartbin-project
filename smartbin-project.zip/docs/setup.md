# Setup Guide

1. Install Node.js and npm
2. Extract the source archive
3. Run `npm install`
4. Start with `npm run dev`
